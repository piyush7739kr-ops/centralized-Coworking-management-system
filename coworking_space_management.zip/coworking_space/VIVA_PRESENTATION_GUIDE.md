# CSC 326: Web Development - Viva & Presentation Master Guide
**Project:** Nexus Cowork - Centralized Coworking Space Management System  
**Student:** Piyush Kumar | **Reg No:** 12611741 | **Section:** K4P26WR | **Domain:** Tech Venture  
**Course Code:** CSC 326 (HTML, CSS, JavaScript)  
**Institution:** Lovely Professional University (LPU)  

---

## 🎙️ 1. 2-Minute Presentation Script (For Examiner / Teacher)

> "Good morning, respected teachers. My name is Piyush Kumar, Reg No 12611741 from section K4P26WR. Today, under our CSC 326 course, I present my project: **Nexus Cowork - Centralized Coworking Space Management System**.
>
> **The Problem:** Traditionally, coworking spaces around our LPU campus—like those at Law Gate, Uni-Mall, and Maheru—rely on Excel spreadsheets, paper registers, or WhatsApp messages. This leads to double bookings, missed updates, and zero live reporting.
>
> **Our Solution:** I developed a role-based web application using HTML5, modern CSS, and Vanilla JavaScript that centralizes three core pillars:
> 1. **Core Records:** Centralized inventory of cabins, studios, and desks around LPU.
> 2. **Role-Based Workflows:** Distinct Member workflows (browsing, dynamic booking, receipt generation) and Admin workflows (inventory additions, status toggling, audit logs).
> 3. **Status Reporting:** Live KPI cards and interactive Chart.js visualizations that compute occupancy percentages and category revenues in real time.
>
> All data persists in the browser using `localStorage`, requiring zero heavy backend dependencies, ensuring ultra-fast load times and clean code architecture."

---

## 🧠 2. Code Architecture & Core Functions Breakdown

When the examiner asks you: *"Explain how your JavaScript code works"*, explain these 5 modular functions:

1. `loadState()` and `saveState()`:
   - Uses `localStorage.getItem()` and `localStorage.setItem()` to store our `spaces` array and `bookings` array in JSON format.
   - Prevents data loss when refreshing the page.

2. `renderSpaces()`:
   - Takes the global `spaces` array, applies user filters (Category, Location, Availability, and Search query using `.filter()`), and injects HTML cards dynamically using JavaScript template literals into `#spacesGrid`.

3. `handleBookingSubmit(event)`:
   - Triggered when the student clicks "Confirm & Generate Receipt".
   - Extracts input values, validates them, creates a unique booking object (`BK-XXX`), pushes it into `bookings`, updates the space status to `Occupied`, calls `saveState()`, and triggers `openReceiptModal()`.

4. `toggleUserRole()`:
   - Switches the active state between `'Member'` and `'Admin'`.
   - Conditionally toggles UI controls: Members see "Reserve This Space", while Admins see "Toggle Status" and "Delete", plus the "Add New Space" management form.

5. `updateAnalytics()`:
   - Calculates the occupancy rate: `(Occupied Spaces / Total Spaces) * 100`.
   - Computes total revenue using JavaScript's `.reduce()` method.
   - Re-renders the Chart.js Donut and Bar charts with live data.

---

## ❓ 3. Top 10 Expected Viva Questions & Perfect Answers

### Q1: Why did you use Vanilla JavaScript instead of frameworks like React or Angular?
**Answer:** "For CSC 326, our syllabus emphasizes core front-end foundations—HTML5, CSS3, and native JavaScript DOM manipulation. Vanilla JavaScript delivers maximum performance, zero build-step overhead, and allows me to demonstrate complete mastery of native events, array methods (`filter`, `map`, `reduce`), and browser APIs like `localStorage`."

### Q2: How does the role-based system work in your project?
**Answer:** "The application maintains a global state variable `currentRole`. When toggled to 'Member', users can only view availability, book available cabins, and view receipts. When toggled to 'Admin', the system unlocks administrative workflows: adding new coworking spaces, overriding statuses (Available ⇄ Maintenance ⇄ Occupied), and accessing the audit table."

### Q3: How do you prevent booking collisions or duplicate data?
**Answer:** "In our centralized model, each space has a unique `id` and a `status` property. When a space is booked, its status transitions from `'Available'` to `'Occupied'`. The UI instantly disables the booking button for other members until the occupant checks out or cancels, completely eliminating double bookings."

### Q4: How is the price calculated in the booking modal?
**Answer:** "We attach an `oninput` event listener to the duration input (`calculateBookingCost()`). It retrieves the active space's `pricePerHour`, multiplies it by the selected duration in hours, and updates the DOM inner text in real time before the form is submitted."

### Q5: How do the charts update when a new space or booking is added?
**Answer:** "We use Chart.js. In our `updateAnalytics()` function, whenever state changes, we re-aggregate the counts and call `chartInstance.update()`. This animates the donut and bar charts smoothly without a full page reload."

### Q6: What happens if a member cancels their booking?
**Answer:** "The `cancelBooking(id)` function finds the booking in the `bookings` array, sets its status to `'Cancelled'`, locates the associated space in the `spaces` array, resets its status back to `'Available'`, updates `localStorage`, and calls `refreshUI()`."

### Q7: How are the LPU locations integrated?
**Answer:** "The inventory reflects real vicinities familiar to our LPU community: Uni-Mall Gate 1, Law Gate market road, Maheru north gate, GT Road Chaheru, Academic Block 34, and Urban Estate. Users can filter specifically by their nearby campus hub."

### Q8: How did you implement printable receipts?
**Answer:** "We wrote a CSS `@media print` query in `style.css`. When `window.print()` is triggered, all background navigation and elements are hidden (`visibility: hidden`), while `#printableReceipt` is set to `visibility: visible`, giving a clean, professional paper invoice."

### Q9: What is DOM manipulation and where did you use it?
**Answer:** "DOM (Document Object Model) manipulation is using JavaScript to dynamically alter HTML elements, attributes, and styles. In our project, we use `document.getElementById()`, `innerHTML`, `classList.add()`, and `classList.remove()` to update cards, open/close modals, and display live toast notifications."

### Q10: How does `localStorage` handle structured data?
**Answer:** "Since `localStorage` only stores strings, we use `JSON.stringify(array)` to serialize our JavaScript objects when saving, and `JSON.parse(string)` to deserialize them back into usable arrays when loading."
